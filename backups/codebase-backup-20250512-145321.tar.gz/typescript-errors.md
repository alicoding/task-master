# TypeScript Error Analysis Report

Total Errors: 1176

## Error Categories

### TS2304: Cannot find name
- Count: 448 (38.1%)
- Fix Strategy: Import missing types or declare variables
- Examples:
  - `src/cli/commands/deduplicate/index.ts: Cannot find name 'ChalkColor'.`
  - `src/cli/commands/deduplicate/index.ts: Cannot find name 'ChalkColor'.`
  - `src/cli/commands/deduplicate/index.ts: Cannot find name 'ChalkColor'.`
  - `src/cli/commands/deduplicate/index.ts: Cannot find name 'ChalkColor'.`
  - `src/cli/commands/deduplicate/index.ts: Cannot find name 'ChalkColor'.`

### TS2339: Property does not exist on type
- Count: 249 (21.2%)
- Fix Strategy: Add missing properties to interfaces, use type assertions
- Examples:
  - `cli/commands/metadata/metadata-command.ts: Property 'metadata' does not exist on type 'TaskOperationResult<any>'.`
  - `cli/commands/metadata/metadata-command.ts: Property 'metadata' does not exist on type 'TaskOperationResult<any>'.`
  - `cli/commands/metadata/metadata-command.ts: Property 'metadata' does not exist on type 'TaskOperationResult<any>'.`
  - `cli/commands/metadata/metadata-command.ts: Property 'metadata' does not exist on type 'TaskOperationResult<any>'.`
  - `cli/commands/metadata/metadata-command.ts: Property 'metadata' does not exist on type 'TaskOperationResult<any>'.`

### OTHER: Other TypeScript errors
- Count: 157 (13.4%)
- Fix Strategy: Review individually
- Examples:
  - `cli/commands/add/add-command.ts: Property 'colorize' is private and only accessible within class 'SimilarTasksUI'.`
  - `cli/commands/add/add-command.ts: Property 'colorize' is private and only accessible within class 'SimilarTasksUI'.`
  - `cli/commands/add/add-command.ts: Property 'colorize' is private and only accessible within class 'SimilarTasksUI'.`
  - `cli/commands/add/add-command.ts: Property 'colorize' is private and only accessible within class 'SimilarTasksUI'.`
  - `cli/commands/interactive/index.ts: Module '../../ui/index.tsx' was resolved to '/Users/ali/tm/task-master/cli/ui/index.tsx', but '--jsx' is not set.`

### TS2345: Argument type error
- Count: 136 (11.6%)
- Fix Strategy: Add type assertions to function arguments
- Examples:
  - `cli/commands/add/add-command.ts: Argument of type 'string' is not assignable to parameter of type 'ChalkColor'.`
  - `cli/commands/add/add-command.ts: Argument of type 'string' is not assignable to parameter of type 'ChalkColor'.`
  - `cli/commands/add/add-command.ts: Argument of type 'string' is not assignable to parameter of type 'ChalkColor'.`
  - `cli/commands/add/add-command.ts: Argument of type 'string' is not assignable to parameter of type 'ChalkColor'.`
  - `cli/commands/deduplicate/lib/formatter-enhanced.ts: Argument of type 'string' is not assignable to parameter of type 'ChalkColor'.`

### TS2305: Module has no exported member
- Count: 78 (6.6%)
- Fix Strategy: Add missing exports or fix import names
- Examples:
  - `cli/commands/dod/index.ts: Module '"../../../core/dod/types"' has no exported member 'DoD'.`
  - `cli/commands/show/index.ts: Module '"../../../core/types"' has no exported member 'HierarchyTask'.`
  - `cli/commands/show/show-graph.ts: Module '"../../../core/types"' has no exported member 'HierarchyTask'.`
  - `cli/commands/triage/lib/interactive-enhanced/utils/colors.ts: Module '"../utils"' has no exported member 'ChalkColor'.`
  - `core/api/types.ts: Module '"../types"' has no exported member 'TaskSearch'.`

### TS2554: Expected X arguments, but got Y
- Count: 48 (4.1%)
- Fix Strategy: Fix function call argument count
- Examples:
  - `core/repository/base.ts: Expected 1-2 arguments, but got 0.`
  - `core/repository/base.ts: Expected 1-2 arguments, but got 0.`
  - `core/repository/base.ts: Expected 2-4 arguments, but got 1.`
  - `core/repository/base.ts: Expected 2-3 arguments, but got 1.`
  - `core/repository/creation.ts: Expected 2-3 arguments, but got 1.`

### TS2322: Type assignment error
- Count: 30 (2.6%)
- Fix Strategy: Add type assertions, fix interface implementations
- Examples:
  - `cli/commands/search/search-handler-clean.ts: Type 'string' is not assignable to type 'TaskStatus | TaskStatus[]'.`
  - `cli/commands/search/search-handler-clean.ts: Type 'string' is not assignable to type 'TaskReadiness | TaskReadiness[]'.`
  - `cli/commands/search/search-handler-clean.ts: Type 'string' is not assignable to type 'TaskStatus | TaskStatus[]'.`
  - `cli/commands/search/search-handler-clean.ts: Type 'string' is not assignable to type 'TaskReadiness | TaskReadiness[]'.`
  - `cli/commands/search/search-handler.ts: Type 'string' is not assignable to type 'TaskStatus | TaskStatus[]'.`

### TS2420: Class incorrectly implements interface
- Count: 16 (1.4%)
- Fix Strategy: Add missing methods and properties to class
- Examples:
  - `core/repository/index-clean.ts: Class 'TaskRepository' incorrectly implements interface 'Omit<BaseTaskRepository, "sqlite" | "db">'.`
  - `core/repository/index-clean.ts: Class 'TaskRepository' incorrectly implements interface 'Omit<TaskCreationRepository, "sqlite" | "db">'.`
  - `core/repository/index-clean.ts: Class 'TaskRepository' incorrectly implements interface 'Omit<TaskMetadataRepository, "sqlite" | "db">'.`
  - `core/repository/index.ts: Class 'TaskRepository' incorrectly implements interface 'Omit<BaseTaskRepository, "sqlite" | "db">'.`
  - `core/repository/index.ts: Class 'TaskRepository' incorrectly implements interface 'Omit<TaskCreationRepository, "sqlite" | "db">'.`

### TS2307: Cannot find module or its corresponding type declarations
- Count: 10 (0.9%)
- Fix Strategy: Fix import paths using @/ path aliases, ensure proper module resolution
- Examples:
  - `cli/commands/triage/lib/interactive-enhanced/display/task-details.ts: Cannot find module '../../../../../core/graph' or its corresponding type declarations.`
  - `cli/commands/triage/lib/interactive-enhanced/handlers/create-subtask.ts: Cannot find module '../../../../../core/repo' or its corresponding type declarations.`
  - `cli/commands/triage/lib/interactive-enhanced/handlers/create-subtask.ts: Cannot find module '../../../../../core/types' or its corresponding type declarations.`
  - `cli/commands/triage/lib/interactive-enhanced/handlers/mark-done.ts: Cannot find module '../../../../../core/repo' or its corresponding type declarations.`
  - `cli/commands/triage/lib/interactive-enhanced/handlers/merge-task.ts: Cannot find module '../../../../../core/repo' or its corresponding type declarations.`

### TS2416: Property not assignable to same property in base type
- Count: 4 (0.3%)
- Fix Strategy: Fix return types in derived classes to match base class
- Examples:
  - `core/repository/index-clean.ts: Property 'getChildTasks' in type 'TaskRepository' is not assignable to the same property in base type 'Omit<TaskHierarchyRepository, "sqlite" | "db">'.`
  - `core/repository/index-clean.ts: Property 'naturalLanguageSearch' in type 'TaskRepository' is not assignable to the same property in base type 'Omit<TaskSearchRepository, "sqlite" | "db">'.`
  - `core/repository/index.ts: Property 'getChildTasks' in type 'TaskRepository' is not assignable to the same property in base type 'Omit<TaskHierarchyRepository, "sqlite" | "db">'.`
  - `core/repository/index.ts: Property 'naturalLanguageSearch' in type 'TaskRepository' is not assignable to the same property in base type 'Omit<TaskSearchRepository, "sqlite" | "db">'.`

## Error Hotspots

- `src/cli/commands/deduplicate/lib`: 282 errors (24.0%)
- `src/cli/commands/triage/lib/interactive-enhanced/handlers`: 72 errors (6.1%)
- `src/core/repository`: 72 errors (6.1%)
- `core/api/handlers`: 60 errors (5.1%)
- `core/repository`: 55 errors (4.7%)
- `src/core/api/handlers`: 55 errors (4.7%)
- `src/cli/commands/search`: 40 errors (3.4%)
- `src/cli/commands/triage/lib/processor`: 31 errors (2.6%)
- `core/capability-map/visualizers/enhanced`: 30 errors (2.6%)
- `src/core/capability-map/visualizers/enhanced`: 30 errors (2.6%)

## Fix Priority

1. Foundation types in core/types.ts and db/schema.ts
2. Repository interface implementations
3. Module resolution issues
4. String literal type assertions
5. Other property and method errors
