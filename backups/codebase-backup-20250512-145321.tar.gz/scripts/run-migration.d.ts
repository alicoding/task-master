/**
 * Script to run the database migration
 * Adds description and body fields to tasks table
 */
export {};
