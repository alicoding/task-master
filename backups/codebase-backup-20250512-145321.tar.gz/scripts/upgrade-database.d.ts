#!/usr/bin/env node
/**
 * Database upgrade script for Task Master
 * Adds description and body columns to tasks table
 */
export {};
