/**
 * Script to fix JSON tags in the database
 */
export {};
