#!/usr/bin/env node
/**
 * Database fix script for Task Master
 * Directly adds description and body columns to tasks table using SQLite
 */
export {};
