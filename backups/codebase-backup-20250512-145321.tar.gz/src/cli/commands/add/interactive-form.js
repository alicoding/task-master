// Symlink redirector file - do not edit directly
import { InteractiveTaskForm } from '@/cli/commands/add/interactive-form';
export { InteractiveTaskForm };
export default InteractiveTaskForm;