/**
 * Help screen display for interactive triage mode
 */

import readline from 'readline';
import { ChalkColor, ChalkStyle } from '@/cli/commands/triage/lib/utils';
import { ChalkColor } from "@/cli/utils/chalk-utils";

/**
 * Display help screen with all available commands
 * @param colorize Colorize function for styling output
 */
export function displayHelpScreen(
  colorize: (text: string, color?: ChalkColor, style?: ChalkStyle) => string
): void {
  console.log(colorize('\n┌' + '─'.repeat(60) + '┐', ('cyan' as ChalkColor)));
  console.log(colorize('│ TRIAGE MODE HELP', ('cyan' as ChalkColor), 'bold') + colorize(' '.repeat(43) + '│', ('cyan' as ChalkColor)));
  console.log(colorize('└' + '─'.repeat(60) + '┘', ('cyan' as ChalkColor)));
  
  console.log(colorize('\nNavigation Commands:', ('blue' as ChalkColor), 'bold'));
  console.log(colorize('  n', ('blue' as ChalkColor)) + ') ' + colorize('Next', ('white' as ChalkColor)) + ' - Move to the next task');
  console.log(colorize('  p', ('blue' as ChalkColor)) + ') ' + colorize('Previous', ('white' as ChalkColor)) + ' - Move to the previous task');
  console.log(colorize('  s', ('gray' as ChalkColor)) + ') ' + colorize('Skip', ('white' as ChalkColor)) + ' - Skip this task (won\'t be marked as processed)');
  console.log(colorize('  q', ('red' as ChalkColor)) + ') ' + colorize('Quit', ('white' as ChalkColor)) + ' - Exit triage mode');
  
  console.log(colorize('\nTask Management Commands:', ('green' as ChalkColor), 'bold'));
  console.log(colorize('  u', ('yellow' as ChalkColor)) + ') ' + colorize('Update', ('white' as ChalkColor)) + ' - Update task status and readiness');
  console.log(colorize('  d', ('green' as ChalkColor)) + ') ' + colorize('Done', ('white' as ChalkColor)) + ' - Mark task as completed');
  console.log(colorize('  t', ('cyan' as ChalkColor)) + ') ' + colorize('Tags', ('white' as ChalkColor)) + ' - Add or remove tags');
  console.log(colorize('  b', ('magenta' as ChalkColor)) + ') ' + colorize('Block/Unblock', ('white' as ChalkColor)) + ' - Toggle blocked status');
  console.log(colorize('  c', ('green' as ChalkColor)) + ') ' + colorize('Create Subtask', ('white' as ChalkColor)) + ' - Add a subtask to this task');
  
  console.log(colorize('\nDuplication Management:', ('yellow' as ChalkColor), 'bold'));
  console.log(colorize('  m', ('red' as ChalkColor)) + ') ' + colorize('Merge', ('white' as ChalkColor)) + ' - Merge with a similar task (only shown when similar tasks exist)');
  
  console.log(colorize('\nOther Commands:', ('magenta' as ChalkColor), 'bold'));
  console.log(colorize('  h', ('cyan' as ChalkColor)) + ') ' + colorize('Help', ('white' as ChalkColor)) + ' - Show this help screen');
  
  console.log(colorize('\nTips:', ('gray' as ChalkColor), 'bold'));
  console.log(colorize('  - Tasks are presented in order: todo, in-progress, done, with draft items first', ('gray' as ChalkColor)));
  console.log(colorize('  - Similar tasks are shown when found, and can be merged to reduce duplication', ('gray' as ChalkColor)));
  console.log(colorize('  - Use the "Block/Unblock" command to quickly toggle a task\'s blocked status', ('gray' as ChalkColor)));
  console.log(colorize('  - Creating subtasks helps break down complex work into manageable pieces', ('gray' as ChalkColor)));
  console.log(colorize('  - Press Ctrl+C at any time to force exit the program', ('gray' as ChalkColor)));
  
  console.log(colorize('\nPress any key to continue...', ('cyan' as ChalkColor)));
  
  // This would be better with a single key press, but we'll use readline for now
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  rl.question('', () => {
    rl.close();
  });
}