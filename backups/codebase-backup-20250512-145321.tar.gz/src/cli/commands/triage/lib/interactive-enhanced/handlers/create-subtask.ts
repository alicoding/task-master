/**
 * Create subtask handler
 */

import readline from 'readline';
import { TaskRepository } from '@/core/repo';
import { TaskStatus } from '@/core/types';
import { ProcessingOptions, TriageResults, TriageTask } from '@/cli/commands/triage/lib/utils';
import { ChalkColor } from "@/cli/utils/chalk-utils";

/**
 * Handle creating a subtask for the current task
 * @param task Parent task 
 * @param repo Task repository
 * @param results Triage results to update
 * @param options Processing options
 */
export async function handleCreateSubtaskAction(
  task: TriageTask,
  repo: TaskRepository,
  results: TriageResults,
  options: ProcessingOptions
): Promise<void> {
  const { dryRun, colorize } = options;
  
  if (dryRun) {
    console.log(colorize('Would create subtask (dry run).', ('yellow' as ChalkColor)));
    results.added.push({
      title: '[Subtask]',
      parentId: task.id,
      dry_run: true
    });
    return;
  }
  
  console.log(colorize('\n┌─ Create Subtask', ('green' as ChalkColor), 'bold'));
  console.log(colorize('│', ('green' as ChalkColor)));
  console.log(colorize('├─ Parent Task: ', ('green' as ChalkColor)) + 
              colorize(task.id || '', ('green' as ChalkColor)) + ': ' + task.title);
  
  // Get subtask details
  const rl1 = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  const titleInput = await new Promise<string>(resolve => {
    rl1.question(colorize('├─ Subtask Title: ', ('green' as ChalkColor)), resolve);
  });
  
  rl1.close();
  
  if (!titleInput.trim()) {
    console.log(colorize('└─ Cancelled - title is required', ('yellow' as ChalkColor)));
    return;
  }
  
  // Get status
  const rl2 = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  const statusMenu = `
${colorize('1', ('blue' as ChalkColor))} - todo
${colorize('2', ('yellow' as ChalkColor))} - in-progress
${colorize('3', ('green' as ChalkColor))} - done
${colorize('0', ('gray' as ChalkColor))} - default (todo)
`;
  
  console.log(colorize('│', ('green' as ChalkColor)));
  console.log(colorize('├─ Status Options:', ('green' as ChalkColor)));
  console.log(statusMenu);
  
  const statusInput = await new Promise<string>(resolve => {
    rl2.question(colorize('├─ Select status [0-3]: ', ('green' as ChalkColor)), resolve);
  });
  
  rl2.close();
  
  // Map input to status
  let status: TaskStatus = 'todo';  // Default
  switch (statusInput) {
    case '1': status = 'todo'; break;
    case '2': status = 'in-progress'; break;
    case '3': status = 'done'; break;
  }
  
  // Get tags
  const rl3 = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  console.log(colorize('│', ('green' as ChalkColor)));
  console.log(colorize('├─ Enter tags (comma-separated) or leave empty:', ('green' as ChalkColor)));
  
  const tagsInput = await new Promise<string>(resolve => {
    rl3.question(colorize('├─ Tags: ', ('green' as ChalkColor)), resolve);
  });
  
  rl3.close();
  
  // Process tags
  const tags = tagsInput.trim() ? 
    tagsInput.split(',').map(t => t.trim()).filter(t => t.length > 0) : 
    [];
  
  // Create the subtask
  console.log(colorize('│', ('green' as ChalkColor)));
  console.log(colorize('├─ Creating subtask...', ('green' as ChalkColor)));
  
  const newTask = await repo.createTask({
    title: titleInput.trim(),
    status,
    readiness: 'draft',
    tags,
    childOf: task.id
  });
  
  results.added.push(newTask);
  console.log(colorize('└─ ✓ Subtask created with ID: ' + newTask.id, ('green' as ChalkColor), 'bold'));
}