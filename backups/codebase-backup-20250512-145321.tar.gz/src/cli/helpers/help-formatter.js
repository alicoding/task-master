// Symlink redirector file - do not edit directly
import { helpFormatter } from '@/cli/helpers/help-formatter';
export { helpFormatter };
export default helpFormatter;