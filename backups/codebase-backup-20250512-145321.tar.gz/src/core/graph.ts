/**
 * Task Graph - Main export file
 * Re-exports the TaskGraph class from the modular structure
 */

export { TaskGraph } from '@/core/graph/index';