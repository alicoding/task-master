/**
 * Matching utilities for NLP-based search and similarity
 */

export * from '@/core/nlp/matchers/fuzzy-matcher';