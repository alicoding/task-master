// Symlink redirector file - do not edit directly
// This file allows imports from @/core to be redirected to the actual CORE directory
import * as core from '../../core/index';
export * from '../../core/index';
export default core;